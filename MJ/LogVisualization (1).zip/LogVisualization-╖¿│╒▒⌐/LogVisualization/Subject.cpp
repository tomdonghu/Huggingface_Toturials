﻿#include "Subject.h"
#include <iostream>
#include <iomanip>
#include <cctype>

using namespace std::string_literals;


Subject& Subject::getInstance(const std::string& fileName)
{
	static Subject subject(fileName);
	return subject;
}
 
Subject::Subject(const std::string& fileName)
	:remainCount(64), currPlayer(-1), round(0), turn(0), step(0)
{
	for (auto& player : players)
		player = std::make_unique<Player>();

	std::ifstream fin(fileName);
	if (!fin)
		std::cerr << "Open file error!"s << std::endl;
	parse(fin);
	maxRound = data.size();
	maxTurn = data[0].size();
}

bool Subject::run()
{
	auto token = parseNextLog();
	
	if (token.empty())
		return false;

	if (token[0] == "流局"s)
		token = parseNextLog();

	if (token[1].find("風"s) != std::string::npos) {
		result = std::make_pair(-1, ""s);
		
		wind = token[1];
		dealer.first = stoi(token[2]);
		dealer.second = stoi(token[3]);

		int roundPlayerIdx = stoi(token[4]);

		token = parseNextLog();

		remainCount = 64;

		for (size_t i = 0; i < 4; ++i) {
			const auto& uid = stoi(token[1]);
			players[uid]->seat = i;
			seats[i] = uid;

			players[uid]->init(token[4], token[9]);
			remainCount -= players[uid]->getBonusCnt();

			token = parseNextLog();
		}
		int roundIdx = std::find(seats.begin(), seats.end(), roundPlayerIdx) - seats.begin();
		for (int i = 0; i < 4; ++i) {
			players[seats[(roundIdx + i) % 4]]->roundWind = i;
		}
		turn = 1;
	}
	action(token);

	return true;
}

void Subject::nextRound()
{
	setRound(++round);
}

void Subject::setRound(size_t r)
{
	maxTurn = data[r].size();
	if (r == 0) {
		round = 0;
		turn = 0;
		step = 0;
		for (auto& p : players)
			p->score = 0;
		run();
		return;
	}

	round = r - 1;
	turn = data[round].size() - 1;
	step = data[round][turn].size() - 1;
	auto tokens = parseNextLog();

	if (tokens[0] == "score"s)
		for (size_t i = 0; i < 4; ++i) {
			players[i]->score = std::stoi(tokens[i + 1]);
		}
	run();
}

void Subject::setTurn(size_t t)
{
	if (t >= maxTurn) {
		return;
	}
	setRound(round);
	while (turn != t && turn != 0) {
		render();
		run();
	}
	run();
}

void Subject::parse(std::ifstream& fin)
{
	using std::string;
	using std::vector;
	vector<vector<string>> temp(100);
	string str;
	int prev = 0;

	while (getline(fin, str)) {
		auto tokens = split(str, ',');
		if ((str.find("風"s) != string::npos && tokens.size() == 5) || tokens[0].empty())
			temp[0].emplace_back(str);
		else if (std::isdigit(tokens[0][0])) {
			const auto turn = std::stoi(tokens[0]);
			prev = (prev != turn) ? turn : prev;
			temp[prev].emplace_back(str);
		}
		else if (tokens[0] == "台"s)
			temp[prev].emplace_back(str);
		else if (str.find("score"s) != string::npos || str.find("流局"s) != string::npos) {
			temp[prev].emplace_back(str);
			temp.resize(prev + 1);
			data.emplace_back(temp);
			temp.clear();
			temp.resize(100);
			prev = 0;
		}
	}
}

void Subject::action(std::vector<std::string> &token)
{
	if (token.empty() || token.size() <= 2)
		return;
	if (token[2] == "聽"s) {
		return;
	}
	if (token[0] == "台"s) {
		countResult(token);
	}
	else if (token[0] == "score"s) {
		for (size_t i = 0; i < 4; ++i) {
			const int& currScore = std::stoi(token[i + 1]);
			players[i]->scoreChange = currScore - players[i]->score;
			players[i]->score = currScore;
		}
	}
	else {
		currPlayer = std::stoi(token[1]);
		auto& player = players[currPlayer];
		player->setHand(token[4]);
		player->setDoor(token[5], token[6], token[7], token[8]);
		player->setBonus(token[9]);
		player->setState(token[2], token[3]);

		if (token[2] == "摸"s) {
			player->drawTile(token[3]);
			--remainCount;
		}
	}
}

void Subject::countResult(const std::vector<std::string>& tokens)
{
	int tai = stoi(tokens[1]);
	const int totalTai = stoi(tokens[3]);
	std::string taiStr = tokens[5];

	if (taiStr.find("自摸"s) != std::string::npos) {
		const int diff = totalTai - tai * 3;
		if (diff != 0 && taiStr.find("莊家"s) == std::string::npos) {
			const std::string cnt = std::to_string(dealer.second);
			if (dealer.second) {
				taiStr += "莊家 連"s + cnt + "拉"s + cnt;
				tai += diff;
			}
		}
	}
	else if (tai != totalTai) {
		tai = totalTai;
		const std::string cnt = std::to_string(dealer.second);
		if (dealer.second)
			taiStr += "莊家 連"s + cnt + "拉"s + cnt;
	}

	result = std::make_pair(tai, taiStr);

	action(parseNextLog());
	std::cout << "第"s << round + 1 << "場  "s;
	for (const auto& player : players)
		std::cout << std::setw(4) << player->scoreChange;
	std::cout << "  p"s << currPlayer
		<< "  台數:"s << std::setw(3) << tai << "  "s
		<< taiStr << std::endl;
}

void Subject::render()
{
	for (auto& player : players)
		player->update();
}

std::array<std::string, 4> Subject::getCredit()
{
	std::array<std::string, 4> credits;
	for (size_t i = 0; i < 4; ++i)
		credits[i] = std::to_string(players[seats[i]]->score);
	return credits;
}

std::array<std::string, 4> Subject::getDealer()
{
	const auto dealerSeat = std::distance(seats.begin(), 
		std::find_if(seats.begin(), seats.end(), [&](const auto& seat) {
			return seat == dealer.first;
		})
	);
	
	std::array<std::string, 4> ret;
	if (dealer.second == 0)
		ret[dealerSeat] = "莊"s;
	else
		ret[dealerSeat] = "莊x"s + std::to_string(dealer.second);
	return ret;
}

std::vector<std::string> Subject::parseNextLog()
{
	std::string str;
	while (1) {
		if (round < data.size()) {
			if (turn < data[round].size()) {
				if (step < data[round][turn].size())
					return split(data[round][turn][step++], ',');
				else {
					++turn;
					step = 0;
					continue;
				}
			}
			else {
				++round;
				turn = 0;
				continue;
			}
		}
		else {
			return {};
		}
	}
}

std::vector<std::string> Subject::split(const std::string& str, const char delimiter)
{
	std::vector<std::string> tokens;
	std::string temp;
	for (const auto& c : str) {
		if (c == delimiter) {
			tokens.emplace_back(temp);
			temp.clear();
		}
		else
			temp += c;
	}
	tokens.emplace_back(temp);
	return tokens;
}