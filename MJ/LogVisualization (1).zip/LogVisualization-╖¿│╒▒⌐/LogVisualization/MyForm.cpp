﻿#include "MyForm.h"

using namespace System;
using namespace System::Windows::Forms;

void main(array<System::String^>^ args)
{
	SetProcessDPIAware();
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	logVisualization::MyForm myForm;
	Application::Run(%myForm);
}