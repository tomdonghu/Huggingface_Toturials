﻿#pragma once
#include <vector>
#include <array>
#include <string>
#include <map>
typedef unsigned int GLuint;

class Subject;

class Player
{
	friend class Subject;
public:
	static void initTexture(); //初始化對應貼圖

	Player();
	void init(const std::string& hand, const std::string& bonus);
	void setHand(const std::string &hand);
	void setDoor(const std::string& chow, const std::string& pong, const std::string& kong, const std::string& concealedKong);
	void setBonus(const std::string&);
	void setState(const std::string& state, const std::string& tile);

	void drawTile(const std::string& draw);
	void discardTile(const std::string& discard);
	
	int getBonusCnt() const { return bonusTexId.size(); }
	void clear();

	void update(); //render
	
private:
	int seat;  //    2
			   // 3     1
			   //    0
	int roundWind;
	int score;
	int scoreChange;

	static std::map<std::string, GLuint>     tileTexId; //麻將貼圖對應id
	static const std::array<std::string, 42> tiles;

	//-1表示無貼圖
	static std::pair<GLuint, bool>*      currTileTexId;   // 當下等待有無碰槓胡的牌
	GLuint                               drawTileTexId;
	GLuint                               actionTexId;     // 碰 槓 胡 自摸
	std::vector<GLuint>                  handTexId; 
	std::vector<GLuint>                  doorTexId; 
	std::vector<GLuint>                  bonusTexId;
	std::vector<std::pair<GLuint, bool>> allDiscardTexId; // pair<已丟的牌貼圖id, 是否被碰槓胡>

	std::vector<std::string>             chow;
	std::vector<std::string>             pong;
	std::vector<std::string>             kong;
	std::vector<std::string>             concealedKong;

	std::vector<std::string> split(const std::string&);
	
	void renderHand();
	void renderTile(const GLuint&);
	void renderDoor();
	void renderAction();
	void renderDiscardTiles();
	
	inline bool isReversed() { return this->seat == 2; }
};

