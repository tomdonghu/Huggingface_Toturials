﻿#pragma once
#include "Player.h"
#include <memory>
#include <fstream>
#include <sstream>
#include <array>
#include <string>
#include <vector>

class Subject
{
	
public:
	size_t maxRound;
	size_t maxTurn;
	std::size_t round;
	std::size_t turn;
	std::size_t step;

	static Subject& getInstance(const std::string&);
	~Subject() = default;

	bool run();
	void nextRound();
	void setRound(size_t);
	void setTurn(size_t);
	void render();

	std::string getWind() { return wind; }
	unsigned int getTime() const { return round + 1; }
	const int getRemainCount() const { return remainCount; }
	const std::array<int, 4>& getSeat() const { return seats; }
	std::array<std::string, 4> getCredit();
	std::array<std::string, 4> getDealer();
	std::pair<int, std::string> getResult() { return result; }

private:
	Subject(const std::string&);
	
	std::vector<std::vector<std::vector<std::string>>> data;
	

	std::string                            wind;
	std::array<std::unique_ptr<Player>, 4> players;
	std::pair<int, int>                    dealer;
	std::array<int, 4>                     seats;
	int                                    currPlayer;  // 當前玩家idx
	unsigned int                           remainCount; // 剩餘張數
	std::pair<int, std::string>            result;      // 結算<台, 牌型>
	void parse(std::ifstream&);
	void action(std::vector<std::string>&);
	void countResult(const std::vector<std::string>&);
	std::vector<std::string> parseNextLog();
	std::vector<std::string> split(const std::string&, const char delimiter);
};

