﻿#include "Player.h"
#include "TextureApp.h"
#include <iostream>

std::map<std::string, GLuint> Player::tileTexId;
std::pair<GLuint, bool>* Player::currTileTexId = nullptr;
const std::array<std::string, 42> Player::tiles = {
		"0A", "1A", "2A", "3A", "4A", "5A", "6A", "7A", "8A",
		"0B", "1B", "2B", "3B", "4B", "5B", "6B", "7B", "8B",
		"0C", "1C", "2C", "3C", "4C", "5C", "6C", "7C", "8C",
		"0D", "1D", "2D",
		"0E", "1E", "2E", "3E",
		"0F", "1F", "2F", "3F", "4F", "5F", "6F", "7F"
};


void Player::initTexture()
{
	static bool isInit = false;
	if (isInit)
		return;
	isInit = true;
	const std::string texPath = "..\\assets\\texture\\";

	auto genTexture = [&](std::string path) {
		return TextureApp::GenTexture(const_cast<char*>((texPath + path).c_str()));
	};

	for (const auto& tile : tiles) {
		tileTexId[tile] = genTexture(tile + ".png");
	}

	tileTexId["chow"] = genTexture("chow.png");
	tileTexId["pon"]  = genTexture("pon.png");
	tileTexId["gon"]  = genTexture("gon.png");
	tileTexId["hu"]   = genTexture("hu.png");
	tileTexId["zimo"] = genTexture("zimo.png");
	tileTexId["back"] = genTexture("back.png");
	tileTexId["east"] = genTexture("east.png");
	tileTexId["south"] = genTexture("south.png");
	tileTexId["west"] = genTexture("west.png");
	tileTexId["north"] = genTexture("north.png");
}

Player::Player()
	:score(0), scoreChange(0),drawTileTexId(-1), actionTexId(-1), roundWind(0)
{
}

void Player::init(const std::string& hand, const std::string& bonus)
{
	this->clear();
	setHand(hand);
	setBonus(bonus);
}

void Player::setHand(const std::string &hand)
{
	handTexId.clear();

	for (const auto &tile : split(hand))
		handTexId.push_back(tileTexId[tile]);
}

void Player::setDoor(const std::string& chow, const std::string& pong, const std::string& kong, const std::string& concealedKong)
{
	using std::string;
	using std::vector;

	auto diffAndReplace = [&, this](const string& str, vector<string>& s2) {
		
		vector<string> s1 = split(str);
		std::sort(s1.begin(), s1.end());
		vector<string> ret;
		std::set_difference(s1.begin(), s1.end(),
			s2.begin(), s2.end(), std::inserter(ret, ret.begin()));
		s2 = s1;
		return ret;
	};
	
	const auto& melds = diffAndReplace(chow, this->chow);
	for (const auto& t : melds) {
		static const char* suits = "ABCDEF";

		int n = std::stoi(t);
		const auto& suit = suits[n / 21];
		const auto& baseRank = (n % 21) / 3;
		int melds[3] = { baseRank,baseRank + 1,baseRank + 2 };

		if (n % 3 == 1)
			std::swap(melds[1], melds[2]);
		else if (n % 3 == 2)
			std::swap(melds[0], melds[1]);
		for (const auto& tile : melds)
			doorTexId.emplace_back(tileTexId[std::to_string(tile) + suit]);

		doorTexId.emplace_back(-1);
	}

	auto func = [&, this](const string& str, vector<string>& s2, int cnt, bool concealed = false) {
		const auto& melds = diffAndReplace(str, s2);
		for (const auto& t : melds) {
			int n = std::stoi(t);
			for (size_t i = 0; i < cnt; ++i) {
				if (concealed && (i == 0 || i == 3))
					doorTexId.emplace_back(tileTexId["back"]);
				else {
					const auto& textureId = tileTexId[tiles[n]];
					doorTexId.emplace_back(textureId);
				}
			}
			doorTexId.emplace_back(-1);
		}
	};

	func(pong, this->pong, 3);
	func(kong, this->kong, 4);
	func(concealedKong, this->concealedKong, 4, true);
}

void Player::setBonus(const std::string& bonus)
{
	bonusTexId.clear();

	for (const auto& tile : split(bonus))
		bonusTexId.emplace_back(tileTexId[tile + "F"]);
}

void Player::drawTile(const std::string& draw)
{
	drawTileTexId = tileTexId[draw];
}

void Player::discardTile(const std::string& discard)
{
	allDiscardTexId.push_back(std::make_pair(tileTexId[discard], false));
	currTileTexId = &allDiscardTexId.back();
}

void Player::setState(const std::string& state, const std::string& tile)
{
	if (state == "丟") {
		discardTile(tile);
	}
	else if (state == "吃") {
		actionTexId = tileTexId["chow"];
		currTileTexId->second = true;
	}
	else if (state == "碰") {
		actionTexId = tileTexId["pon"];
		currTileTexId->second = true;
	}
	else if (state == "槓") {
		actionTexId = tileTexId["gon"];
		currTileTexId->second = true;
	}
	else if (state == "加槓") {
		actionTexId = tileTexId["gon"];
		currTileTexId->second = true;
		const auto it = std::find(doorTexId.begin(), doorTexId.end(), doorTexId[doorTexId.size() - 2]);
		doorTexId.insert(it, doorTexId[doorTexId.size() - 2]);
		for (size_t i = 0; i < 5; ++i)
			doorTexId.pop_back();
	}
	else if (state == "暗槓") {
		actionTexId = tileTexId["gon"];
	}
	else if (state == "胡") {
		actionTexId = tileTexId["hu"];
	}
	else if (state == "自摸") {
		actionTexId = tileTexId["zimo"];
	}
}



void Player::clear()
{
	currTileTexId = nullptr;

	this->drawTileTexId = -1;
	this->actionTexId = -1;

	this->handTexId.clear();
	this->doorTexId.clear();
	this->allDiscardTexId.clear();
	this->bonusTexId.clear();

	this->chow.clear();
	this->pong.clear();
	this->kong.clear();
	this->concealedKong.clear();
}

void Player::update()
{
	glEnable(GL_TEXTURE_2D);

	glPushMatrix();

	glTranslatef(8, 8, 0);

	switch (seat)
	{
	case 0:
		break;
	case 1:
		glTranslatef(0, -8, 0);
		glRotatef(90, 0, 0, 1);
		glTranslatef(8, -84, 0);
		break;
	case 2:
		glRotatef(180, 0, 0, 1);
		glTranslatef(-84, -84, 0);
		break;
	case  3:
		glTranslatef(0, -8, 0);
		glRotatef(-90, 0, 0, 1);
		glTranslatef(-92, 0, 0);
		break;
	}

	glPushMatrix();
	glTranslatef(40.5, 32, 0);
	static const std::string w[4] = { "east","south","west","north" };
	glBindTexture(GL_TEXTURE_2D, tileTexId[w[roundWind]]);
	glScalef(3, 3, 3);
	glBegin(GL_QUADS);
	glTexCoord2d(0, 0); glVertex2d(0, 0);
	glTexCoord2d(1, 0); glVertex2d(1, 0);
	glTexCoord2d(1, 1); glVertex2d(1, 1);
	glTexCoord2d(0, 1); glVertex2d(0, 1);
	glEnd();
	glPopMatrix();

	glPushMatrix();
	glScalef(3.5, 3.5, 3.5);
	glTranslatef(3, 0, 0);
	glTranslatef(16 - handTexId.size(), 0, 0);
	renderHand();

	glTranslatef(1, 0, 0);

	if (drawTileTexId != -1) {
		renderTile(drawTileTexId);
		drawTileTexId = -1;
	}
	glPopMatrix();


	renderDoor();
	renderAction();
	renderDiscardTiles();

	glPopMatrix();
	glDisable(GL_TEXTURE_2D);
}

void Player::renderHand()
{
	for (const auto &id : handTexId) {
		renderTile(id);
		glTranslatef(1, 0, 0);
	}
}

void Player::renderTile(const GLuint& id)
{
	glPushMatrix();

	glBindTexture(GL_TEXTURE_2D, id);

	if (isReversed()) {
		glBegin(GL_QUADS);
		glTexCoord2d(0, 0); glVertex2d(1, 2);
		glTexCoord2d(1, 0); glVertex2d(0, 2);
		glTexCoord2d(1, 1); glVertex2d(0, 0);
		glTexCoord2d(0, 1); glVertex2d(1, 0);
		glEnd();
	}
	else {
		glBegin(GL_QUADS);
		glTexCoord2d(0, 0); glVertex2d(0, 0);
		glTexCoord2d(1, 0); glVertex2d(1, 0);
		glTexCoord2d(1, 1); glVertex2d(1, 2);
		glTexCoord2d(0, 1); glVertex2d(0, 2);
		glEnd();
	}

	glPopMatrix();
}

void Player::renderDoor()
{
	glPushMatrix();

	glTranslatef(10, 10, 0);
	glScalef(2, 2, 2);
	for (const auto &id : bonusTexId) {
		renderTile(id);
		glTranslatef(1, 0, 0);
	}

	glTranslatef(1, 0, 0);
	glScalef(1.2, 1.2, 1.2);
	for (const auto &id : doorTexId) {
		if (id == -1) {
			glTranslatef(0.3, 0, 0);
		}
		else {
			renderTile(id);
			glTranslatef(1, 0, 0);
		}
	}

	glPopMatrix();
}

void Player::renderAction()
{
	glPushMatrix();

	glTranslatef(22, -8, 0);
	glScaled(3.5, 3.5, 3.5);
	
	if (actionTexId != -1) {
		glBindTexture(GL_TEXTURE_2D, actionTexId);

		glBegin(GL_QUADS);
		if (isReversed()) {
			glTexCoord2d(0, 0); glVertex2d(2, 2);
			glTexCoord2d(1, 0); glVertex2d(0, 2);
			glTexCoord2d(1, 1); glVertex2d(0, 0);
			glTexCoord2d(0, 1); glVertex2d(2, 0);
		}
		else {
			glTexCoord2d(0, 0); glVertex2d(0, 0);
			glTexCoord2d(1, 0); glVertex2d(2, 0);
			glTexCoord2d(1, 1); glVertex2d(2, 2);
			glTexCoord2d(0, 1); glVertex2d(0, 2);
		}
		glEnd();

		actionTexId = -1;
	}

	glPopMatrix();
}

void Player::renderDiscardTiles()
{
	glPushMatrix();

	glTranslatef(24, 24, 0);
	glScalef(3, 3, 3);
	
	int tileCnt = 0;
	for (const auto& tile : allDiscardTexId) {
		const auto& [id, stolen] = tile;
		if (!stolen) {
			renderTile(id);
			++tileCnt;
			tileCnt % 9 == 0 ? glTranslatef(-8, -2, 0) : glTranslatef(1, 0, 0);
		}
	}

	glPopMatrix();
}

std::vector<std::string> Player::split(const std::string& s)
{
	char *str = const_cast<char*>(s.c_str());
	char *token;
	token = strtok(str, " ");
	std::vector<std::string> result;
	while (token != NULL) {
		result.push_back(token);
		token = strtok(NULL, " ");
	}
	return result;
}


